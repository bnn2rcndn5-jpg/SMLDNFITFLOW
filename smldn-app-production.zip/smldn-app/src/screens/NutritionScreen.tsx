import React, { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';

interface NutritionScreenProps {
  user: any;
}

interface FoodItem {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export default function NutritionScreen({ user }: NutritionScreenProps) {
  const [foods, setFoods] = useState<FoodItem[]>([
    { id: '1', name: 'Chicken Breast (200g)', calories: 330, protein: 62, carbs: 0, fat: 7 },
    { id: '2', name: 'Brown Rice (150g)', calories: 195, protein: 5, carbs: 43, fat: 2 },
    { id: '3', name: 'Broccoli (100g)', calories: 34, protein: 3, carbs: 7, fat: 0 },
  ]);

  const [newFood, setNewFood] = useState('');

  const totals = foods.reduce((acc, food) => ({
    calories: acc.calories + food.calories,
    protein: acc.protein + food.protein,
    carbs: acc.carbs + food.carbs,
    fat: acc.fat + food.fat,
  }), { calories: 0, protein: 0, carbs: 0, fat: 0 });

  const targets = {
    calories: 2500,
    protein: 200,
    carbs: 300,
    fat: 80,
  };

  const removeFood = (id: string) => {
    setFoods(foods.filter(f => f.id !== id));
  };

  return (
    <div className="screen-container">
      <style>{`
        .nutrition-header {
          margin-bottom: 1.5rem;
        }

        .nutrition-title {
          font-size: 1.5rem;
          font-weight: 700;
          color: #000;
          margin-bottom: 0.5rem;
        }

        .nutrition-subtitle {
          font-size: 0.875rem;
          color: #666;
        }

        .macro-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
          gap: 1rem;
          margin-bottom: 1.5rem;
        }

        .macro-box {
          background: white;
          border-radius: 12px;
          padding: 1.5rem;
          text-align: center;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
          border-top: 4px solid #FF4500;
        }

        .macro-value {
          font-size: 1.75rem;
          font-weight: 700;
          color: #FF4500;
          margin-bottom: 0.25rem;
        }

        .macro-label {
          font-size: 0.875rem;
          color: #666;
          margin-bottom: 0.5rem;
        }

        .macro-target {
          font-size: 0.75rem;
          color: #999;
        }

        .progress-bar {
          width: 100%;
          height: 6px;
          background-color: #E0E0E0;
          border-radius: 3px;
          overflow: hidden;
          margin-top: 0.5rem;
        }

        .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, #FF4500 0%, #FF6B35 100%);
          transition: width 0.3s ease;
        }

        .card {
          background: white;
          border-radius: 12px;
          padding: 1.5rem;
          margin-bottom: 1rem;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        .card-title {
          font-size: 1.25rem;
          font-weight: 600;
          margin-bottom: 1rem;
          color: #000;
        }

        .food-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1rem;
          background-color: #F5F5F5;
          border-radius: 8px;
          margin-bottom: 0.75rem;
        }

        .food-name {
          font-weight: 600;
          color: #000;
          margin-bottom: 0.25rem;
        }

        .food-macros {
          font-size: 0.75rem;
          color: #666;
        }

        .food-calories {
          font-size: 1.25rem;
          font-weight: 700;
          color: #FF4500;
          text-align: right;
          min-width: 80px;
        }

        .delete-btn {
          background: none;
          border: none;
          color: #F44336;
          cursor: pointer;
          padding: 0.5rem;
          transition: all 0.3s ease;
        }

        .delete-btn:hover {
          transform: scale(1.2);
        }

        .add-food-form {
          display: flex;
          gap: 0.5rem;
          margin-bottom: 1rem;
        }

        .food-input {
          flex: 1;
          padding: 0.75rem;
          border: 2px solid #E0E0E0;
          border-radius: 8px;
          font-size: 1rem;
        }

        .food-input:focus {
          outline: none;
          border-color: #FF4500;
        }

        .add-btn {
          padding: 0.75rem 1.5rem;
          background-color: #FF4500;
          color: white;
          border: none;
          border-radius: 8px;
          cursor: pointer;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          transition: all 0.3s ease;
        }

        .add-btn:hover {
          background-color: #E63E00;
        }

        .tip-section {
          background-color: #FFF3E0;
          border-left: 4px solid #FF4500;
          padding: 1rem;
          border-radius: 8px;
          margin-top: 1.5rem;
        }

        .tip-title {
          font-weight: 600;
          color: #FF4500;
          margin-bottom: 0.5rem;
        }

        .tip-text {
          font-size: 0.875rem;
          color: #666;
        }
      `}</style>

      <div className="nutrition-header">
        <div className="nutrition-title">Nutrition Tracker</div>
        <div className="nutrition-subtitle">Track your daily macros</div>
      </div>

      <div className="macro-grid">
        <div className="macro-box">
          <div className="macro-label">Calories</div>
          <div className="macro-value">{totals.calories}</div>
          <div className="macro-target">/ {targets.calories}</div>
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{ width: `${Math.min((totals.calories / targets.calories) * 100, 100)}%` }}
            />
          </div>
        </div>

        <div className="macro-box">
          <div className="macro-label">Protein</div>
          <div className="macro-value">{totals.protein}g</div>
          <div className="macro-target">/ {targets.protein}g</div>
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{ width: `${Math.min((totals.protein / targets.protein) * 100, 100)}%` }}
            />
          </div>
        </div>

        <div className="macro-box">
          <div className="macro-label">Carbs</div>
          <div className="macro-value">{totals.carbs}g</div>
          <div className="macro-target">/ {targets.carbs}g</div>
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{ width: `${Math.min((totals.carbs / targets.carbs) * 100, 100)}%` }}
            />
          </div>
        </div>

        <div className="macro-box">
          <div className="macro-label">Fat</div>
          <div className="macro-value">{totals.fat}g</div>
          <div className="macro-target">/ {targets.fat}g</div>
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{ width: `${Math.min((totals.fat / targets.fat) * 100, 100)}%` }}
            />
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-title">Today's Meals</div>

        <div className="add-food-form">
          <input
            type="text"
            className="food-input"
            placeholder="Add food..."
            value={newFood}
            onChange={(e) => setNewFood(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && newFood) {
                setFoods([...foods, {
                  id: Date.now().toString(),
                  name: newFood,
                  calories: 100,
                  protein: 10,
                  carbs: 10,
                  fat: 5,
                }]);
                setNewFood('');
              }
            }}
          />
          <button 
            className="add-btn"
            onClick={() => {
              if (newFood) {
                setFoods([...foods, {
                  id: Date.now().toString(),
                  name: newFood,
                  calories: 100,
                  protein: 10,
                  carbs: 10,
                  fat: 5,
                }]);
                setNewFood('');
              }
            }}
          >
            <Plus size={20} />
            Add
          </button>
        </div>

        {foods.map(food => (
          <div key={food.id} className="food-item">
            <div>
              <div className="food-name">{food.name}</div>
              <div className="food-macros">
                P: {food.protein}g | C: {food.carbs}g | F: {food.fat}g
              </div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <div className="food-calories">{food.calories}</div>
              <button 
                className="delete-btn"
                onClick={() => removeFood(food.id)}
              >
                <Trash2 size={20} />
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="tip-section">
        <div className="tip-title">💡 Nutrition Tip</div>
        <div className="tip-text">
          Aim for 0.8-1g of protein per pound of body weight for muscle growth. Distribute your protein intake throughout the day for optimal muscle protein synthesis.
        </div>
      </div>
    </div>
  );
}
