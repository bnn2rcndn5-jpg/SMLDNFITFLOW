import React from 'react';
import { LogOut, User, Mail, Cake, Ruler, Weight } from 'lucide-react';

interface ProfileScreenProps {
  user: any;
  onLogout: () => void;
}

export default function ProfileScreen({ user, onLogout }: ProfileScreenProps) {
  const bmi = (user.weight / ((user.height / 100) ** 2)).toFixed(1);

  return (
    <div className="screen-container">
      <style>{`
        .profile-header {
          background: linear-gradient(135deg, #FF4500 0%, #E63E00 100%);
          color: white;
          padding: 2rem;
          border-radius: 12px;
          margin-bottom: 1.5rem;
          text-align: center;
        }

        .profile-avatar {
          width: 80px;
          height: 80px;
          border-radius: 50%;
          background-color: rgba(255, 255, 255, 0.2);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 2.5rem;
          margin: 0 auto 1rem;
        }

        .profile-name {
          font-size: 1.75rem;
          font-weight: 700;
          margin-bottom: 0.5rem;
        }

        .profile-email {
          font-size: 0.875rem;
          opacity: 0.9;
        }

        .card {
          background: white;
          border-radius: 12px;
          padding: 1.5rem;
          margin-bottom: 1rem;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        .card-title {
          font-size: 1.25rem;
          font-weight: 600;
          margin-bottom: 1rem;
          color: #000;
        }

        .profile-item {
          display: flex;
          align-items: center;
          gap: 1rem;
          padding: 1rem;
          background-color: #F5F5F5;
          border-radius: 8px;
          margin-bottom: 0.75rem;
        }

        .profile-icon {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          background-color: #FF4500;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .profile-info {
          flex: 1;
        }

        .profile-label {
          font-size: 0.75rem;
          color: #666;
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }

        .profile-value {
          font-size: 1.125rem;
          font-weight: 600;
          color: #000;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 1rem;
          margin-bottom: 1rem;
        }

        .stat-box {
          background-color: #F5F5F5;
          padding: 1rem;
          border-radius: 8px;
          text-align: center;
          border-top: 3px solid #FF4500;
        }

        .stat-value {
          font-size: 1.5rem;
          font-weight: 700;
          color: #FF4500;
          margin-bottom: 0.25rem;
        }

        .stat-label {
          font-size: 0.75rem;
          color: #666;
        }

        .settings-section {
          margin-bottom: 1.5rem;
        }

        .setting-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1rem;
          background-color: #F5F5F5;
          border-radius: 8px;
          margin-bottom: 0.75rem;
        }

        .setting-label {
          font-weight: 600;
          color: #000;
        }

        .toggle-switch {
          width: 50px;
          height: 28px;
          background-color: #E0E0E0;
          border-radius: 14px;
          border: none;
          cursor: pointer;
          position: relative;
          transition: all 0.3s ease;
        }

        .toggle-switch.active {
          background-color: #FF4500;
        }

        .toggle-switch::after {
          content: '';
          position: absolute;
          width: 24px;
          height: 24px;
          background-color: white;
          border-radius: 50%;
          top: 2px;
          left: 2px;
          transition: all 0.3s ease;
        }

        .toggle-switch.active::after {
          left: 24px;
        }

        .logout-btn {
          width: 100%;
          padding: 1rem;
          background-color: #F44336;
          color: white;
          border: none;
          border-radius: 8px;
          font-size: 1rem;
          font-weight: 600;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          transition: all 0.3s ease;
          margin-top: 1rem;
        }

        .logout-btn:hover {
          background-color: #D32F2F;
          transform: scale(1.02);
        }
      `}</style>

      <div className="profile-header">
        <div className="profile-avatar">👤</div>
        <div className="profile-name">{user.name}</div>
        <div className="profile-email">{user.email}</div>
      </div>

      <div className="card">
        <div className="card-title">Personal Info</div>
        
        <div className="profile-item">
          <div className="profile-icon">
            <User size={20} />
          </div>
          <div className="profile-info">
            <div className="profile-label">Name</div>
            <div className="profile-value">{user.name}</div>
          </div>
        </div>

        <div className="profile-item">
          <div className="profile-icon">
            <Mail size={20} />
          </div>
          <div className="profile-info">
            <div className="profile-label">Email</div>
            <div className="profile-value">{user.email}</div>
          </div>
        </div>

        <div className="profile-item">
          <div className="profile-icon">
            <Cake size={20} />
          </div>
          <div className="profile-info">
            <div className="profile-label">Age</div>
            <div className="profile-value">{user.age} years</div>
          </div>
        </div>

        <div className="profile-item">
          <div className="profile-icon">
            <Ruler size={20} />
          </div>
          <div className="profile-info">
            <div className="profile-label">Height</div>
            <div className="profile-value">{user.height} cm</div>
          </div>
        </div>

        <div className="profile-item">
          <div className="profile-icon">
            <Weight size={20} />
          </div>
          <div className="profile-info">
            <div className="profile-label">Weight</div>
            <div className="profile-value">{user.weight} kg</div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-title">Body Metrics</div>
        <div className="stats-grid">
          <div className="stat-box">
            <div className="stat-value">{bmi}</div>
            <div className="stat-label">BMI</div>
          </div>
          <div className="stat-box">
            <div className="stat-value">24</div>
            <div className="stat-label">Workouts</div>
          </div>
          <div className="stat-box">
            <div className="stat-value">12</div>
            <div className="stat-label">Day Streak</div>
          </div>
          <div className="stat-box">
            <div className="stat-value">1850</div>
            <div className="stat-label">Points</div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-title">Preferences</div>
        <div className="settings-section">
          <div className="setting-item">
            <div className="setting-label">Push Notifications</div>
            <button className="toggle-switch active" />
          </div>
          <div className="setting-item">
            <div className="setting-label">Email Reminders</div>
            <button className="toggle-switch active" />
          </div>
          <div className="setting-item">
            <div className="setting-label">Share Progress</div>
            <button className="toggle-switch" />
          </div>
        </div>
      </div>

      <button className="logout-btn" onClick={onLogout}>
        <LogOut size={20} />
        Sign Out
      </button>
    </div>
  );
}
