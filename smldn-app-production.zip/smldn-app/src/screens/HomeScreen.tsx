import React, { useState, useEffect } from 'react';
import { Flame, TrendingUp, Target, Award } from 'lucide-react';

interface HomeScreenProps {
  user: any;
}

export default function HomeScreen({ user }: HomeScreenProps) {
  const [stats, setStats] = useState({
    streak: 12,
    caloriesBurned: 342,
    caloriesTarget: 500,
    steps: 8234,
    stepsTarget: 10000,
    workoutsCompleted: 24,
  });

  return (
    <div className="screen-container">
      <style>{`
        .welcome-section {
          background: linear-gradient(135deg, #FF4500 0%, #E63E00 100%);
          color: white;
          padding: 2rem;
          border-radius: 12px;
          margin-bottom: 1.5rem;
        }

        .welcome-text {
          font-size: 1.5rem;
          font-weight: 700;
          margin-bottom: 0.5rem;
        }

        .welcome-subtitle {
          font-size: 0.875rem;
          opacity: 0.9;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 1rem;
          margin-bottom: 1.5rem;
        }

        .stat-box {
          background: linear-gradient(135deg, #FF4500 0%, #E63E00 100%);
          color: white;
          padding: 1.5rem;
          border-radius: 12px;
          text-align: center;
        }

        .stat-icon {
          font-size: 1.75rem;
          margin-bottom: 0.5rem;
        }

        .stat-value {
          font-size: 1.75rem;
          font-weight: 700;
          margin-bottom: 0.25rem;
        }

        .stat-label {
          font-size: 0.75rem;
          opacity: 0.9;
        }

        .card {
          background: white;
          border-radius: 12px;
          padding: 1.5rem;
          margin-bottom: 1rem;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        .card-title {
          font-size: 1.25rem;
          font-weight: 600;
          margin-bottom: 1rem;
          color: #000;
        }

        .progress-item {
          margin-bottom: 1.5rem;
        }

        .progress-label {
          display: flex;
          justify-content: space-between;
          margin-bottom: 0.5rem;
          font-size: 0.875rem;
          font-weight: 600;
        }

        .progress-bar {
          width: 100%;
          height: 8px;
          background-color: #E0E0E0;
          border-radius: 4px;
          overflow: hidden;
        }

        .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, #FF4500 0%, #FF6B35 100%);
          transition: width 0.3s ease;
        }

        .tip-box {
          background-color: #FFF3E0;
          border-left: 4px solid #FF4500;
          padding: 1rem;
          border-radius: 8px;
          margin-bottom: 1rem;
        }

        .tip-title {
          font-weight: 600;
          color: #FF4500;
          margin-bottom: 0.5rem;
        }

        .tip-text {
          font-size: 0.875rem;
          color: #666;
        }
      `}</style>

      <div className="welcome-section">
        <div className="welcome-text">Welcome back, {user.name}! 👋</div>
        <div className="welcome-subtitle">Let's crush your fitness goals today</div>
      </div>

      <div className="stats-grid">
        <div className="stat-box">
          <div className="stat-icon">🔥</div>
          <div className="stat-value">{stats.streak}</div>
          <div className="stat-label">Day Streak</div>
        </div>
        <div className="stat-box">
          <div className="stat-icon">💪</div>
          <div className="stat-value">{stats.workoutsCompleted}</div>
          <div className="stat-label">Workouts</div>
        </div>
        <div className="stat-box">
          <div className="stat-icon">⚡</div>
          <div className="stat-value">{stats.caloriesBurned}</div>
          <div className="stat-label">Calories</div>
        </div>
        <div className="stat-box">
          <div className="stat-icon">👟</div>
          <div className="stat-value">{(stats.steps / 1000).toFixed(1)}k</div>
          <div className="stat-label">Steps</div>
        </div>
      </div>

      <div className="card">
        <div className="card-title">Today's Progress</div>
        
        <div className="progress-item">
          <div className="progress-label">
            <span>Calories Burned</span>
            <span>{stats.caloriesBurned}/{stats.caloriesTarget}</span>
          </div>
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{ width: `${(stats.caloriesBurned / stats.caloriesTarget) * 100}%` }}
            />
          </div>
        </div>

        <div className="progress-item">
          <div className="progress-label">
            <span>Steps</span>
            <span>{stats.steps}/{stats.stepsTarget}</span>
          </div>
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{ width: `${(stats.steps / stats.stepsTarget) * 100}%` }}
            />
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-title">💡 Fitness Tip</div>
        <div className="tip-box">
          <div className="tip-title">Stay Hydrated</div>
          <div className="tip-text">
            Drinking water before, during, and after workouts helps maintain performance and aids recovery. Aim for at least 8 glasses per day!
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-title">📅 This Week</div>
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: '0.5rem' }}>
          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, idx) => (
            <div key={day} style={{
              flex: 1,
              textAlign: 'center',
              padding: '0.75rem',
              background: idx < 5 ? '#FF4500' : '#E0E0E0',
              color: idx < 5 ? 'white' : '#666',
              borderRadius: '8px',
              fontSize: '0.75rem',
              fontWeight: '600'
            }}>
              {day}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
