import React, { useState } from 'react';
import { Trophy, Zap, Target } from 'lucide-react';

interface SocialScreenProps {
  user: any;
}

export default function SocialScreen({ user }: SocialScreenProps) {
  const [leaderboard] = useState([
    { rank: 1, name: 'Alex Thompson', score: 2450, streak: 28 },
    { rank: 2, name: 'Sarah Johnson', score: 2380, streak: 25 },
    { rank: 3, name: 'Mike Davis', score: 2210, streak: 22 },
    { rank: 4, name: 'Emma Wilson', score: 2100, streak: 18 },
    { rank: 5, name: 'You', score: 1850, streak: 12 },
    { rank: 6, name: 'Chris Lee', score: 1720, streak: 15 },
    { rank: 7, name: 'Lisa Anderson', score: 1650, streak: 10 },
  ]);

  const [challenges] = useState([
    {
      id: '1',
      title: '7-Day Step Challenge',
      description: 'Walk 50,000 steps this week',
      progress: 35000,
      target: 50000,
      reward: '500 XP',
    },
    {
      id: '2',
      title: 'Workout Warrior',
      description: 'Complete 10 workouts',
      progress: 7,
      target: 10,
      reward: '750 XP',
    },
    {
      id: '3',
      title: 'Macro Master',
      description: 'Hit your macros for 5 days',
      progress: 3,
      target: 5,
      reward: '600 XP',
    },
  ]);

  return (
    <div className="screen-container">
      <style>{`
        .social-header {
          margin-bottom: 1.5rem;
        }

        .social-title {
          font-size: 1.5rem;
          font-weight: 700;
          color: #000;
          margin-bottom: 0.5rem;
        }

        .social-subtitle {
          font-size: 0.875rem;
          color: #666;
        }

        .card {
          background: white;
          border-radius: 12px;
          padding: 1.5rem;
          margin-bottom: 1rem;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        .card-title {
          font-size: 1.25rem;
          font-weight: 600;
          margin-bottom: 1rem;
          color: #000;
        }

        .leaderboard-item {
          display: flex;
          align-items: center;
          gap: 1rem;
          padding: 1rem;
          background-color: #F5F5F5;
          border-radius: 8px;
          margin-bottom: 0.75rem;
          transition: all 0.3s ease;
        }

        .leaderboard-item:hover {
          background-color: #E0E0E0;
        }

        .leaderboard-item.highlight {
          background: linear-gradient(135deg, #FFF3E0 0%, #FFE0B2 100%);
          border-left: 4px solid #FF4500;
        }

        .rank-badge {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 700;
          color: white;
          font-size: 1.25rem;
          flex-shrink: 0;
        }

        .rank-badge.gold {
          background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
        }

        .rank-badge.silver {
          background: linear-gradient(135deg, #C0C0C0 0%, #A9A9A9 100%);
        }

        .rank-badge.bronze {
          background: linear-gradient(135deg, #CD7F32 0%, #B87333 100%);
        }

        .rank-badge.default {
          background: linear-gradient(135deg, #FF4500 0%, #E63E00 100%);
        }

        .leaderboard-info {
          flex: 1;
        }

        .leaderboard-name {
          font-weight: 600;
          color: #000;
          margin-bottom: 0.25rem;
        }

        .leaderboard-stats {
          font-size: 0.75rem;
          color: #666;
        }

        .leaderboard-score {
          font-size: 1.25rem;
          font-weight: 700;
          color: #FF4500;
          text-align: right;
        }

        .challenge-item {
          background-color: #F5F5F5;
          border-radius: 8px;
          padding: 1rem;
          margin-bottom: 1rem;
          border-left: 4px solid #FF4500;
        }

        .challenge-header {
          display: flex;
          justify-content: space-between;
          align-items: start;
          margin-bottom: 0.75rem;
        }

        .challenge-title {
          font-weight: 600;
          color: #000;
        }

        .challenge-reward {
          background-color: #FF4500;
          color: white;
          padding: 0.25rem 0.75rem;
          border-radius: 4px;
          font-size: 0.75rem;
          font-weight: 600;
        }

        .challenge-description {
          font-size: 0.875rem;
          color: #666;
          margin-bottom: 0.75rem;
        }

        .progress-bar {
          width: 100%;
          height: 8px;
          background-color: #E0E0E0;
          border-radius: 4px;
          overflow: hidden;
          margin-bottom: 0.5rem;
        }

        .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, #FF4500 0%, #FF6B35 100%);
          transition: width 0.3s ease;
        }

        .progress-text {
          font-size: 0.75rem;
          color: #666;
          text-align: right;
        }

        .achievement-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
          gap: 1rem;
        }

        .achievement-badge {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 0.5rem;
          padding: 1rem;
          background: linear-gradient(135deg, #FF4500 0%, #E63E00 100%);
          color: white;
          border-radius: 12px;
          text-align: center;
          font-size: 0.75rem;
          font-weight: 600;
        }

        .achievement-icon {
          font-size: 2rem;
        }
      `}</style>

      <div className="social-header">
        <div className="social-title">Community</div>
        <div className="social-subtitle">Connect and compete with friends</div>
      </div>

      <div className="card">
        <div className="card-title">🏆 Leaderboard</div>
        {leaderboard.map(user => {
          let rankBadgeClass = 'default';
          if (user.rank === 1) rankBadgeClass = 'gold';
          else if (user.rank === 2) rankBadgeClass = 'silver';
          else if (user.rank === 3) rankBadgeClass = 'bronze';

          return (
            <div 
              key={user.rank} 
              className={`leaderboard-item ${user.name === 'You' ? 'highlight' : ''}`}
            >
              <div className={`rank-badge ${rankBadgeClass}`}>
                {user.rank === 1 && '👑'}
                {user.rank === 2 && '🥈'}
                {user.rank === 3 && '🥉'}
                {user.rank > 3 && user.rank}
              </div>
              <div className="leaderboard-info">
                <div className="leaderboard-name">{user.name}</div>
                <div className="leaderboard-stats">🔥 {user.streak} day streak</div>
              </div>
              <div className="leaderboard-score">{user.score}</div>
            </div>
          );
        })}
      </div>

      <div className="card">
        <div className="card-title">⚡ Active Challenges</div>
        {challenges.map(challenge => (
          <div key={challenge.id} className="challenge-item">
            <div className="challenge-header">
              <div className="challenge-title">{challenge.title}</div>
              <div className="challenge-reward">{challenge.reward}</div>
            </div>
            <div className="challenge-description">{challenge.description}</div>
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ width: `${(challenge.progress / challenge.target) * 100}%` }}
              />
            </div>
            <div className="progress-text">
              {challenge.progress} / {challenge.target}
            </div>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="card-title">🎖️ Achievements</div>
        <div className="achievement-grid">
          <div className="achievement-badge">
            <div className="achievement-icon">🔥</div>
            <div>7-Day Streak</div>
          </div>
          <div className="achievement-badge">
            <div className="achievement-icon">💪</div>
            <div>First Workout</div>
          </div>
          <div className="achievement-badge">
            <div className="achievement-icon">🎯</div>
            <div>Macro Master</div>
          </div>
          <div className="achievement-badge">
            <div className="achievement-icon">👑</div>
            <div>Top 10</div>
          </div>
        </div>
      </div>
    </div>
  );
}
