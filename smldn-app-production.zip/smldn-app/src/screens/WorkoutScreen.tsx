import React, { useState } from 'react';
import { ChevronDown, CheckCircle2 } from 'lucide-react';

interface WorkoutScreenProps {
  user: any;
}

export default function WorkoutScreen({ user }: WorkoutScreenProps) {
  const [expandedDay, setExpandedDay] = useState<string | null>('monday');
  const [completedExercises, setCompletedExercises] = useState<string[]>([]);

  const workouts = {
    monday: {
      day: 'Monday',
      title: 'Upper Body Strength',
      duration: '45 min',
      exercises: [
        { id: '1', name: 'Bench Press', sets: 4, reps: 6, weight: '80kg' },
        { id: '2', name: 'Barbell Rows', sets: 4, reps: 6, weight: '85kg' },
        { id: '3', name: 'Overhead Press', sets: 3, reps: 8, weight: '50kg' },
        { id: '4', name: 'Pull-ups', sets: 3, reps: 8, weight: 'BW' },
        { id: '5', name: 'Dumbbell Curls', sets: 3, reps: 10, weight: '25kg' },
      ]
    },
    wednesday: {
      day: 'Wednesday',
      title: 'Lower Body Strength',
      duration: '50 min',
      exercises: [
        { id: '6', name: 'Squats', sets: 4, reps: 6, weight: '120kg' },
        { id: '7', name: 'Deadlifts', sets: 3, reps: 5, weight: '140kg' },
        { id: '8', name: 'Leg Press', sets: 3, reps: 8, weight: '200kg' },
        { id: '9', name: 'Leg Curls', sets: 3, reps: 10, weight: '60kg' },
        { id: '10', name: 'Calf Raises', sets: 3, reps: 15, weight: '100kg' },
      ]
    },
    friday: {
      day: 'Friday',
      title: 'Full Body Power',
      duration: '55 min',
      exercises: [
        { id: '11', name: 'Power Cleans', sets: 5, reps: 3, weight: '70kg' },
        { id: '12', name: 'Front Squats', sets: 4, reps: 5, weight: '100kg' },
        { id: '13', name: 'Incline Bench', sets: 3, reps: 8, weight: '70kg' },
        { id: '14', name: 'Barbell Rows', sets: 4, reps: 5, weight: '90kg' },
        { id: '15', name: 'Box Jumps', sets: 3, reps: 5, weight: 'BW' },
      ]
    }
  };

  const toggleExercise = (exerciseId: string) => {
    setCompletedExercises(prev =>
      prev.includes(exerciseId)
        ? prev.filter(id => id !== exerciseId)
        : [...prev, exerciseId]
    );
  };

  const toggleDay = (day: string) => {
    setExpandedDay(expandedDay === day ? null : day);
  };

  return (
    <div className="screen-container">
      <style>{`
        .workout-header {
          margin-bottom: 1.5rem;
        }

        .workout-title {
          font-size: 1.5rem;
          font-weight: 700;
          color: #000;
          margin-bottom: 0.5rem;
        }

        .workout-subtitle {
          font-size: 0.875rem;
          color: #666;
        }

        .workout-card {
          background: white;
          border-radius: 12px;
          margin-bottom: 1rem;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
          overflow: hidden;
        }

        .workout-header-btn {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1.5rem;
          background: linear-gradient(135deg, #FF4500 0%, #E63E00 100%);
          color: white;
          border: none;
          cursor: pointer;
          width: 100%;
          font-size: 1rem;
          font-weight: 600;
          transition: all 0.3s ease;
        }

        .workout-header-btn:hover {
          transform: translateX(4px);
        }

        .workout-info {
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex: 1;
        }

        .workout-day {
          font-size: 1.25rem;
          font-weight: 700;
        }

        .workout-duration {
          font-size: 0.875rem;
          opacity: 0.9;
        }

        .chevron {
          transition: transform 0.3s ease;
        }

        .chevron.open {
          transform: rotate(180deg);
        }

        .exercises-list {
          padding: 0;
          max-height: 0;
          overflow: hidden;
          transition: max-height 0.3s ease;
        }

        .exercises-list.open {
          max-height: 1000px;
          padding: 1.5rem;
          border-top: 2px solid #E0E0E0;
        }

        .exercise-item {
          display: flex;
          align-items: center;
          gap: 1rem;
          padding: 1rem;
          background-color: #F5F5F5;
          border-radius: 8px;
          margin-bottom: 0.75rem;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .exercise-item:hover {
          background-color: #E0E0E0;
        }

        .exercise-item.completed {
          background-color: #E8F5E9;
        }

        .exercise-checkbox {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          border: 2px solid #FF4500;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          transition: all 0.3s ease;
        }

        .exercise-item.completed .exercise-checkbox {
          background-color: #FF4500;
          color: white;
        }

        .exercise-details {
          flex: 1;
        }

        .exercise-name {
          font-weight: 600;
          color: #000;
          margin-bottom: 0.25rem;
        }

        .exercise-specs {
          font-size: 0.875rem;
          color: #666;
        }

        .exercise-weight {
          font-weight: 600;
          color: #FF4500;
          text-align: right;
          min-width: 60px;
        }

        .tip-section {
          background-color: #FFF3E0;
          border-left: 4px solid #FF4500;
          padding: 1rem;
          border-radius: 8px;
          margin-top: 1.5rem;
        }

        .tip-title {
          font-weight: 600;
          color: #FF4500;
          margin-bottom: 0.5rem;
        }

        .tip-text {
          font-size: 0.875rem;
          color: #666;
        }
      `}</style>

      <div className="workout-header">
        <div className="workout-title">4-Week Periodized Plan</div>
        <div className="workout-subtitle">AI-Generated Workout Program</div>
      </div>

      {Object.entries(workouts).map(([key, workout]: any) => (
        <div key={key} className="workout-card">
          <button 
            className="workout-header-btn"
            onClick={() => toggleDay(key)}
          >
            <div className="workout-info">
              <div>
                <div className="workout-day">{workout.day}</div>
                <div className="workout-duration">{workout.title} • {workout.duration}</div>
              </div>
            </div>
            <ChevronDown 
              size={24} 
              className={`chevron ${expandedDay === key ? 'open' : ''}`}
            />
          </button>

          <div className={`exercises-list ${expandedDay === key ? 'open' : ''}`}>
            {workout.exercises.map((exercise: any) => (
              <div
                key={exercise.id}
                className={`exercise-item ${completedExercises.includes(exercise.id) ? 'completed' : ''}`}
                onClick={() => toggleExercise(exercise.id)}
              >
                <div className="exercise-checkbox">
                  {completedExercises.includes(exercise.id) && (
                    <CheckCircle2 size={20} />
                  )}
                </div>
                <div className="exercise-details">
                  <div className="exercise-name">{exercise.name}</div>
                  <div className="exercise-specs">
                    {exercise.sets} sets × {exercise.reps} reps
                  </div>
                </div>
                <div className="exercise-weight">{exercise.weight}</div>
              </div>
            ))}
          </div>
        </div>
      ))}

      <div className="tip-section">
        <div className="tip-title">💡 Workout Tip</div>
        <div className="tip-text">
          Rest 2-3 minutes between heavy compound lifts and 60-90 seconds between isolation exercises. This allows your nervous system to recover for maximum strength gains.
        </div>
      </div>
    </div>
  );
}
