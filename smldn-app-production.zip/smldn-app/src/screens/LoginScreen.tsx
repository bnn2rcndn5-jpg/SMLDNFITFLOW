import React, { useState } from 'react';
import { LogIn } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (user: any) => void;
}

export default function LoginScreen({ onLogin }: LoginScreenProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    age: '',
    height: '',
    weight: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isSignUp) {
      if (!formData.name || !formData.email || !formData.password || !formData.age || !formData.height || !formData.weight) {
        alert('Please fill in all fields');
        return;
      }
      
      const user = {
        id: Date.now().toString(),
        name: formData.name,
        email: formData.email,
        age: parseInt(formData.age),
        height: parseFloat(formData.height),
        weight: parseFloat(formData.weight),
      };
      
      onLogin(user);
    } else {
      // Demo login
      if (formData.email === 'demo@smldn.com' && formData.password === 'demo123') {
        const user = {
          id: '1',
          name: 'Demo User',
          email: 'demo@smldn.com',
          age: 28,
          height: 180,
          weight: 75,
        };
        onLogin(user);
      } else {
        alert('Invalid credentials. Try demo@smldn.com / demo123');
      }
    }
  };

  return (
    <div className="login-container">
      <style>{`
        .login-container {
          min-height: 100vh;
          background: linear-gradient(135deg, #FF4500 0%, #E63E00 100%);
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 1rem;
        }

        .login-card {
          background: white;
          border-radius: 16px;
          padding: 2rem;
          width: 100%;
          max-width: 400px;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
        }

        .login-header {
          text-align: center;
          margin-bottom: 2rem;
        }

        .login-title {
          font-size: 2rem;
          font-weight: 700;
          color: #000;
          margin-bottom: 0.5rem;
          letter-spacing: 0.1em;
        }

        .login-subtitle {
          font-size: 0.875rem;
          color: #666;
        }

        .form-group {
          margin-bottom: 1.5rem;
        }

        .form-label {
          display: block;
          margin-bottom: 0.5rem;
          font-weight: 600;
          color: #333;
        }

        .form-input {
          width: 100%;
          padding: 0.75rem;
          border: 2px solid #E0E0E0;
          border-radius: 8px;
          font-size: 1rem;
          transition: all 0.3s ease;
        }

        .form-input:focus {
          outline: none;
          border-color: #FF4500;
          box-shadow: 0 0 0 3px rgba(255, 69, 0, 0.1);
        }

        .form-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
        }

        .btn-submit {
          width: 100%;
          padding: 0.75rem;
          background: linear-gradient(135deg, #FF4500 0%, #E63E00 100%);
          color: white;
          border: none;
          border-radius: 8px;
          font-size: 1rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
        }

        .btn-submit:hover {
          transform: scale(1.02);
          box-shadow: 0 4px 12px rgba(255, 69, 0, 0.3);
        }

        .toggle-auth {
          text-align: center;
          margin-top: 1.5rem;
          font-size: 0.875rem;
          color: #666;
        }

        .toggle-auth button {
          background: none;
          border: none;
          color: #FF4500;
          cursor: pointer;
          font-weight: 600;
          text-decoration: underline;
        }

        .demo-hint {
          background-color: #F5F5F5;
          padding: 1rem;
          border-radius: 8px;
          margin-top: 1.5rem;
          font-size: 0.875rem;
          color: #666;
          border-left: 4px solid #FF4500;
        }

        .demo-hint strong {
          color: #FF4500;
        }
      `}</style>

      <div className="login-card">
        <div className="login-header">
          <h1 className="login-title">SMLDN</h1>
          <p className="login-subtitle">Fitness AI</p>
        </div>

        <form onSubmit={handleSubmit}>
          {isSignUp && (
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input
                type="text"
                name="name"
                className="form-input"
                placeholder="Your name"
                value={formData.name}
                onChange={handleChange}
              />
            </div>
          )}

          <div className="form-group">
            <label className="form-label">Email</label>
            <input
              type="email"
              name="email"
              className="form-input"
              placeholder="your@email.com"
              value={formData.email}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              type="password"
              name="password"
              className="form-input"
              placeholder="••••••••"
              value={formData.password}
              onChange={handleChange}
            />
          </div>

          {isSignUp && (
            <>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Age</label>
                  <input
                    type="number"
                    name="age"
                    className="form-input"
                    placeholder="25"
                    value={formData.age}
                    onChange={handleChange}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Height (cm)</label>
                  <input
                    type="number"
                    name="height"
                    className="form-input"
                    placeholder="180"
                    value={formData.height}
                    onChange={handleChange}
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Weight (kg)</label>
                <input
                  type="number"
                  name="weight"
                  className="form-input"
                  placeholder="75"
                  value={formData.weight}
                  onChange={handleChange}
                />
              </div>
            </>
          )}

          <button type="submit" className="btn-submit">
            <LogIn size={20} />
            {isSignUp ? 'Create Account' : 'Sign In'}
          </button>
        </form>

        <div className="toggle-auth">
          {isSignUp ? (
            <>
              Already have an account? <button onClick={() => setIsSignUp(false)}>Sign In</button>
            </>
          ) : (
            <>
              Don't have an account? <button onClick={() => setIsSignUp(true)}>Sign Up</button>
            </>
          )}
        </div>

        {!isSignUp && (
          <div className="demo-hint">
            <strong>Demo Account:</strong><br />
            Email: demo@smldn.com<br />
            Password: demo123
          </div>
        )}
      </div>
    </div>
  );
}
