import React, { useState, useEffect } from 'react';
import { Home, Dumbbell, Apple, Users, User, LogOut, Menu, X } from 'lucide-react';
import HomeScreen from './screens/HomeScreen';
import WorkoutScreen from './screens/WorkoutScreen';
import NutritionScreen from './screens/NutritionScreen';
import SocialScreen from './screens/SocialScreen';
import ProfileScreen from './screens/ProfileScreen';
import LoginScreen from './screens/LoginScreen';
import './App.css';

type Screen = 'home' | 'workout' | 'nutrition' | 'social' | 'profile';

interface User {
  id: string;
  name: string;
  email: string;
  age: number;
  height: number;
  weight: number;
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    // Check if user is logged in (from localStorage)
    const savedUser = localStorage.getItem('smldn_user');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
        setIsLoggedIn(true);
      } catch (e) {
        localStorage.removeItem('smldn_user');
      }
    }
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
    setIsLoggedIn(true);
    localStorage.setItem('smldn_user', JSON.stringify(userData));
    setCurrentScreen('home');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUser(null);
    localStorage.removeItem('smldn_user');
    setCurrentScreen('home');
  };

  if (!isLoggedIn) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="app-container">
      {/* Header */}
      <header className="app-header">
        <div className="header-content">
          <div className="logo-section">
            <h1 className="app-title">SMLDN</h1>
            <p className="app-subtitle">Fitness AI</p>
          </div>
          <button 
            className="menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="app-main">
        {currentScreen === 'home' && <HomeScreen user={user} />}
        {currentScreen === 'workout' && <WorkoutScreen user={user} />}
        {currentScreen === 'nutrition' && <NutritionScreen user={user} />}
        {currentScreen === 'social' && <SocialScreen user={user} />}
        {currentScreen === 'profile' && <ProfileScreen user={user} onLogout={handleLogout} />}
      </main>

      {/* Bottom Navigation */}
      <nav className={`bottom-nav ${mobileMenuOpen ? 'open' : ''}`}>
        <button
          className={`nav-item ${currentScreen === 'home' ? 'active' : ''}`}
          onClick={() => {
            setCurrentScreen('home');
            setMobileMenuOpen(false);
          }}
        >
          <Home size={24} />
          <span>Home</span>
        </button>
        <button
          className={`nav-item ${currentScreen === 'workout' ? 'active' : ''}`}
          onClick={() => {
            setCurrentScreen('workout');
            setMobileMenuOpen(false);
          }}
        >
          <Dumbbell size={24} />
          <span>Workouts</span>
        </button>
        <button
          className={`nav-item ${currentScreen === 'nutrition' ? 'active' : ''}`}
          onClick={() => {
            setCurrentScreen('nutrition');
            setMobileMenuOpen(false);
          }}
        >
          <Apple size={24} />
          <span>Nutrition</span>
        </button>
        <button
          className={`nav-item ${currentScreen === 'social' ? 'active' : ''}`}
          onClick={() => {
            setCurrentScreen('social');
            setMobileMenuOpen(false);
          }}
        >
          <Users size={24} />
          <span>Social</span>
        </button>
        <button
          className={`nav-item ${currentScreen === 'profile' ? 'active' : ''}`}
          onClick={() => {
            setCurrentScreen('profile');
            setMobileMenuOpen(false);
          }}
        >
          <User size={24} />
          <span>Profile</span>
        </button>
      </nav>
    </div>
  );
}
